package com.example.gamepadoverlay

import org.json.JSONObject
import java.util.UUID

/**
 * Ekranda gösterilecek tek bir sanal gamepad tuşunu tanımlar.
 * Tüm konumlar ekran boyutundan bağımsız olsun diye 0..1 arası
 * yüzdelik (percent) değerler olarak saklanır.
 */
data class ButtonConfig(
    var id: String = UUID.randomUUID().toString(),
    var label: String = "A",
    var xPercent: Float = 0.5f,      // butonun ekrandaki X konumu (sol kenar)
    var yPercent: Float = 0.5f,      // butonun ekrandaki Y konumu (üst kenar)
    var sizeDp: Int = 64,            // buton çapı / kenarı
    var opacity: Int = 80,           // 0-100 arası şeffaflık
    var shape: String = "circle",    // "circle" veya "square"
    var targetXPercent: Float = 0.5f, // basıldığında dokunulacak nokta X
    var targetYPercent: Float = 0.5f  // basıldığında dokunulacak nokta Y
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("label", label)
        o.put("xPercent", xPercent.toDouble())
        o.put("yPercent", yPercent.toDouble())
        o.put("sizeDp", sizeDp)
        o.put("opacity", opacity)
        o.put("shape", shape)
        o.put("targetXPercent", targetXPercent.toDouble())
        o.put("targetYPercent", targetYPercent.toDouble())
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): ButtonConfig {
            return ButtonConfig(
                id = o.optString("id", UUID.randomUUID().toString()),
                label = o.optString("label", "A"),
                xPercent = o.optDouble("xPercent", 0.5).toFloat(),
                yPercent = o.optDouble("yPercent", 0.5).toFloat(),
                sizeDp = o.optInt("sizeDp", 64),
                opacity = o.optInt("opacity", 80),
                shape = o.optString("shape", "circle"),
                targetXPercent = o.optDouble("targetXPercent", 0.5).toFloat(),
                targetYPercent = o.optDouble("targetYPercent", 0.5).toFloat()
            )
        }

        fun defaultSet(): MutableList<ButtonConfig> {
            return mutableListOf(
                ButtonConfig(label = "YUKARI", xPercent = 0.08f, yPercent = 0.55f, targetXPercent = 0.08f, targetYPercent = 0.55f),
                ButtonConfig(label = "AŞAĞI", xPercent = 0.08f, yPercent = 0.75f, targetXPercent = 0.08f, targetYPercent = 0.75f),
                ButtonConfig(label = "SOL", xPercent = 0.02f, yPercent = 0.65f, targetXPercent = 0.02f, targetYPercent = 0.65f),
                ButtonConfig(label = "SAĞ", xPercent = 0.14f, yPercent = 0.65f, targetXPercent = 0.14f, targetYPercent = 0.65f),
                ButtonConfig(label = "A", xPercent = 0.85f, yPercent = 0.75f, shape = "circle", targetXPercent = 0.85f, targetYPercent = 0.75f),
                ButtonConfig(label = "B", xPercent = 0.92f, yPercent = 0.62f, shape = "circle", targetXPercent = 0.92f, targetYPercent = 0.62f)
            )
        }
    }
}
