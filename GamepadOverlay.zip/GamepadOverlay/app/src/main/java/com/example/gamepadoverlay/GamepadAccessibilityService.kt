package com.example.gamepadoverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Gamepad tuşuna basıldığında, ekranda seçilen "hedef nokta"ya
 * sentetik bir dokunuş (tap) göndermeyi sağlayan erişilebilirlik servisi.
 * Bu sayede sanal tuşlar, dokunmatik kontrollü oyunların üzerine
 * "gerçek" bir dokunuşmuş gibi komut iletebilir.
 */
class GamepadAccessibilityService : AccessibilityService() {

    companion object {
        var instance: GamepadAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Bu uygulama ekran içeriğini okumuyor, sadece jest göndermek için kullanılıyor.
    }

    override fun onInterrupt() {}

    /** Belirtilen ekran koordinatına kısa bir dokunuş (tap) gönderir. */
    fun performTapAt(x: Float, y: Float, durationMs: Long = 40L) {
        val path = Path()
        path.moveTo(x, y)
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /** Basılı tutma senaryoları için: basılı tut - bırakma ayrı çağrılabilir. */
    fun performLongPressAt(x: Float, y: Float, durationMs: Long = 400L) {
        performTapAt(x, y, durationMs)
    }
}
