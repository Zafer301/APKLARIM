package com.example.gamepadoverlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.max
import kotlin.math.min

/**
 * Ekranın üzerinde şeffaf, sürüklenebilir/boyutlandırılabilir gamepad
 * tuşlarını gösteren ön plan servisi.
 */
class OverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "gamepad_channel"
        const val NOTIF_ID = 1001

        const val ACTION_START = "com.example.gamepadoverlay.action.START"
        const val ACTION_TOGGLE_EDIT = "com.example.gamepadoverlay.action.TOGGLE_EDIT"
        const val ACTION_STOP = "com.example.gamepadoverlay.action.STOP"
        const val ACTION_REFRESH = "com.example.gamepadoverlay.action.REFRESH"
    }

    private lateinit var windowManager: WindowManager
    private val buttonWindows = mutableListOf<View>()
    private var editMode = true

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        editMode = PrefsManager.isEditMode(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE_EDIT -> {
                editMode = !editMode
                PrefsManager.setEditMode(this, editMode)
                renderButtons()
                updateNotification()
            }
            ACTION_STOP -> {
                stopOverlay()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                renderButtons()
            }
            else -> {
                startForeground(NOTIF_ID, buildNotification())
                renderButtons()
                PrefsManager.setOverlayRunning(this, true)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        clearButtonWindows()
        PrefsManager.setOverlayRunning(this, false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ----------------------------------------------------------------
    // Bildirim
    // ----------------------------------------------------------------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): android.app.Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)

        val toggleIntent = Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_EDIT)
        val togglePending = PendingIntent.getService(this, 1, toggleIntent, flags)

        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent, flags)

        val toggleLabel = if (editMode)
            getString(R.string.notif_action_toggle_edit_off) else getString(R.string.notif_action_toggle_edit)

        val text = if (editMode) getString(R.string.notif_text_edit) else getString(R.string.notif_text_normal)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, toggleLabel, togglePending)
            .addAction(0, getString(R.string.notif_action_stop), stopPending)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification())
    }

    // ----------------------------------------------------------------
    // Tuşların çizimi
    // ----------------------------------------------------------------

    private fun stopOverlay() {
        clearButtonWindows()
        PrefsManager.setOverlayRunning(this, false)
        stopForeground(true)
        stopSelf()
    }

    private fun clearButtonWindows() {
        buttonWindows.forEach { v ->
            try { windowManager.removeView(v) } catch (_: Exception) {}
        }
        buttonWindows.clear()
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    private fun screenWidth(): Int = resources.displayMetrics.widthPixels
    private fun screenHeight(): Int = resources.displayMetrics.heightPixels

    private fun renderButtons() {
        clearButtonWindows()
        val buttons = PrefsManager.loadButtons(this)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        for (config in buttons) {
            addButtonWindow(config, overlayType)
        }
    }

    private fun addButtonWindow(config: ButtonConfig, overlayType: Int) {
        val handleExtraPx = if (editMode) dpToPx(28) else 0
        val sizePx = dpToPx(config.sizeDp)
        val winSize = sizePx + handleExtraPx

        val root = FrameLayout(this)

        val buttonView = TextView(this)
        buttonView.text = config.label
        buttonView.gravity = Gravity.CENTER
        buttonView.setTextColor(getColorCompat(R.color.text_primary))
        buttonView.textSize = 13f
        buttonView.background = getDrawableCompat(
            if (config.shape == "square") R.drawable.bg_button_square else R.drawable.bg_button_circle
        )
        buttonView.alpha = config.opacity / 100f
        val bp = FrameLayout.LayoutParams(sizePx, sizePx)
        bp.gravity = Gravity.TOP or Gravity.START
        root.addView(buttonView, bp)

        val winParams = WindowManager.LayoutParams(
            winSize, winSize,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        winParams.gravity = Gravity.TOP or Gravity.START
        winParams.x = (config.xPercent * screenWidth()).toInt()
        winParams.y = (config.yPercent * screenHeight()).toInt()

        if (editMode) {
            val handle = View(this)
            handle.background = getDrawableCompat(R.drawable.bg_resize_handle)
            val hSize = dpToPx(20)
            val hp = FrameLayout.LayoutParams(hSize, hSize)
            hp.gravity = Gravity.BOTTOM or Gravity.END
            root.addView(handle, hp)
            attachResizeHandleTouch(handle, root, config, winParams)
        } else {
            attachPressTouch(buttonView, config)
        }

        attachDragTouch(buttonView, root, config, winParams)

        windowManager.addView(root, winParams)
        buttonWindows.add(root)
    }

    // ----------------------------------------------------------------
    // Dokunma davranışları
    // ----------------------------------------------------------------

    private fun attachPressTouch(view: View, config: ButtonConfig) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = min(1f, (config.opacity / 100f) + 0.2f)
                    val tx = config.targetXPercent * screenWidth()
                    val ty = config.targetYPercent * screenHeight()
                    GamepadAccessibilityService.instance?.performTapAt(tx, ty)
                    vibrate()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = config.opacity / 100f
                    true
                }
                else -> false
            }
        }
    }

    private fun attachDragTouch(
        buttonView: View,
        root: FrameLayout,
        config: ButtonConfig,
        params: WindowManager.LayoutParams
    ) {
        if (!editMode) return
        var startTouchX = 0f
        var startTouchY = 0f
        var startX = 0
        var startY = 0

        buttonView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startTouchX = event.rawX
                    startTouchY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - startTouchX).toInt()
                    val dy = (event.rawY - startTouchY).toInt()
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    config.xPercent = max(0f, min(1f, params.x.toFloat() / screenWidth()))
                    config.yPercent = max(0f, min(1f, params.y.toFloat() / screenHeight()))
                    persistSingleButton(config)
                    true
                }
                else -> false
            }
        }
    }

    private fun attachResizeHandleTouch(
        handle: View,
        root: FrameLayout,
        config: ButtonConfig,
        params: WindowManager.LayoutParams
    ) {
        var startTouchX = 0f
        var startSizePx = dpToPx(config.sizeDp)

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startTouchX = event.rawX
                    startSizePx = dpToPx(config.sizeDp)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - startTouchX).toInt()
                    val newSizePx = max(dpToPx(32), min(dpToPx(160), startSizePx + dx))
                    val handleExtra = dpToPx(28)
                    params.width = newSizePx + handleExtra
                    params.height = newSizePx + handleExtra
                    windowManager.updateViewLayout(root, params)
                    val bp = (root.getChildAt(0).layoutParams as FrameLayout.LayoutParams)
                    bp.width = newSizePx
                    bp.height = newSizePx
                    root.getChildAt(0).layoutParams = bp
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val finalSizePx = (root.getChildAt(0).layoutParams as FrameLayout.LayoutParams).width
                    config.sizeDp = (finalSizePx / resources.displayMetrics.density).toInt()
                    persistSingleButton(config)
                    true
                }
                else -> false
            }
        }
    }

    private fun persistSingleButton(updated: ButtonConfig) {
        val list = PrefsManager.loadButtons(this)
        val idx = list.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            list[idx] = updated
            PrefsManager.saveButtons(this, list)
        }
    }

    private fun vibrate() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(15)
        }
    }

    private fun getColorCompat(resId: Int) = androidx.core.content.ContextCompat.getColor(this, resId)
    private fun getDrawableCompat(resId: Int) = androidx.core.content.ContextCompat.getDrawable(this, resId)
}
