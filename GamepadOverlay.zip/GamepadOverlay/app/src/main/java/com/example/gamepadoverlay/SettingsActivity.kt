package com.example.gamepadoverlay

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SettingsActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: ButtonAdapter
    private lateinit var tvEmpty: TextView
    private lateinit var seekGlobalOpacity: SeekBar
    private lateinit var seekGlobalSize: SeekBar

    private var buttons: MutableList<ButtonConfig> = mutableListOf()
    private var pickerOverlay: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        recycler = findViewById(R.id.recyclerButtons)
        tvEmpty = findViewById(R.id.tvEmpty)
        seekGlobalOpacity = findViewById(R.id.seekGlobalOpacity)
        seekGlobalSize = findViewById(R.id.seekGlobalSize)
        val fabAdd = findViewById<View>(R.id.fabAdd)

        buttons = PrefsManager.loadButtons(this)
        adapter = ButtonAdapter(buttons, ::openEditDialog, ::deleteButton)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter
        refreshEmptyState()

        seekGlobalOpacity.progress = PrefsManager.getGlobalOpacity(this)
        seekGlobalSize.progress = PrefsManager.getGlobalSize(this)

        seekGlobalOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val value = seekBar?.progress ?: return
                PrefsManager.setGlobalOpacity(this@SettingsActivity, value)
                buttons.forEach { it.opacity = value }
                PrefsManager.saveButtons(this@SettingsActivity, buttons)
                adapter.updateData(buttons)
                notifyOverlayRefresh()
            }
        })

        seekGlobalSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val value = (seekBar?.progress ?: return).coerceAtLeast(32)
                PrefsManager.setGlobalSize(this@SettingsActivity, value)
                buttons.forEach { it.sizeDp = value }
                PrefsManager.saveButtons(this@SettingsActivity, buttons)
                adapter.updateData(buttons)
                notifyOverlayRefresh()
            }
        })

        fabAdd.setOnClickListener {
            openEditDialog(null)
        }
    }

    private fun refreshEmptyState() {
        tvEmpty.visibility = if (buttons.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun notifyOverlayRefresh() {
        if (PrefsManager.isOverlayRunning(this)) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_REFRESH))
        }
    }

    private fun deleteButton(config: ButtonConfig) {
        buttons.removeAll { it.id == config.id }
        PrefsManager.saveButtons(this, buttons)
        adapter.updateData(buttons)
        refreshEmptyState()
        notifyOverlayRefresh()
        Toast.makeText(this, R.string.toast_button_deleted, Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("InflateParams")
    private fun openEditDialog(existing: ButtonConfig?) {
        val isNew = existing == null
        val working = existing?.copy() ?: ButtonConfig(
            sizeDp = PrefsManager.getGlobalSize(this),
            opacity = PrefsManager.getGlobalOpacity(this)
        )

        val view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_button, null)
        val editLabel = view.findViewById<EditText>(R.id.editLabel)
        val seekSize = view.findViewById<SeekBar>(R.id.seekSize)
        val seekOpacity = view.findViewById<SeekBar>(R.id.seekOpacity)
        val radioShape = view.findViewById<RadioGroup>(R.id.radioShape)
        val radioCircle = view.findViewById<RadioButton>(R.id.radioCircle)
        val radioSquare = view.findViewById<RadioButton>(R.id.radioSquare)
        val btnPickTarget = view.findViewById<android.widget.Button>(R.id.btnPickTarget)

        editLabel.setText(working.label)
        seekSize.progress = working.sizeDp
        seekOpacity.progress = working.opacity
        if (working.shape == "square") radioSquare.isChecked = true else radioCircle.isChecked = true

        btnPickTarget.setOnClickListener {
            startTargetPicker { xPercent, yPercent ->
                working.targetXPercent = xPercent
                working.targetYPercent = yPercent
                Toast.makeText(this, R.string.toast_target_saved, Toast.LENGTH_SHORT).show()
            }
        }

        val dialogBuilder = AlertDialog.Builder(this)
            .setTitle(if (isNew) R.string.dialog_add_title else R.string.dialog_edit_title)
            .setView(view)
            .setPositiveButton(R.string.dialog_save, null)
            .setNegativeButton(R.string.dialog_cancel, null)

        if (!isNew) {
            dialogBuilder.setNeutralButton(R.string.dialog_delete) { _, _ ->
                deleteButton(working)
            }
        }

        val dialog = dialogBuilder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                working.label = editLabel.text.toString().ifBlank { "TUŞ" }
                working.sizeDp = seekSize.progress.coerceAtLeast(24)
                working.opacity = seekOpacity.progress.coerceAtLeast(10)
                working.shape = if (radioShape.checkedRadioButtonId == R.id.radioSquare) "square" else "circle"

                if (isNew) {
                    buttons.add(working)
                } else {
                    val idx = buttons.indexOfFirst { it.id == working.id }
                    if (idx >= 0) buttons[idx] = working
                }
                PrefsManager.saveButtons(this, buttons)
                adapter.updateData(buttons)
                refreshEmptyState()
                notifyOverlayRefresh()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    /**
     * Ekranın tamamını kaplayan şeffaf bir katman gösterir; kullanıcı dokununca
     * o noktanın ekran yüzdesini geri döndürür. "Hedef" nokta seçimi içindir.
     */
    private fun startTargetPicker(onPicked: (Float, Float) -> Unit) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val container = FrameLayout(this)
        container.setBackgroundColor(Color.parseColor("#B3000000"))

        val hint = TextView(this)
        hint.text = getString(R.string.target_pick_overlay_hint)
        hint.setTextColor(Color.WHITE)
        hint.textSize = 16f
        hint.gravity = Gravity.CENTER
        val hintParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        )
        hintParams.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        hintParams.topMargin = 120
        container.addView(hint, hintParams)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        container.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val xPercent = event.rawX / resources.displayMetrics.widthPixels
                val yPercent = event.rawY / resources.displayMetrics.heightPixels
                onPicked(xPercent.coerceIn(0f, 1f), yPercent.coerceIn(0f, 1f))
                pickerOverlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                pickerOverlay = null
            }
            true
        }

        try {
            wm.addView(container, params)
            pickerOverlay = container
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_overlay_perm_needed, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pickerOverlay?.let {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            try { wm.removeView(it) } catch (_: Exception) {}
        }
    }
}
