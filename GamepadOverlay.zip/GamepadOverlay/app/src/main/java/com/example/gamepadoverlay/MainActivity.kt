package com.example.gamepadoverlay

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayTitle: TextView
    private lateinit var tvAccessTitle: TextView
    private lateinit var btnGrantOverlay: Button
    private lateinit var btnGrantAccess: Button
    private lateinit var btnOpenSettings: Button
    private lateinit var btnToggleOverlay: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayTitle = findViewById(R.id.tvOverlayTitle)
        tvAccessTitle = findViewById(R.id.tvAccessTitle)
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay)
        btnGrantAccess = findViewById(R.id.btnGrantAccess)
        btnOpenSettings = findViewById(R.id.btnOpenSettings)
        btnToggleOverlay = findViewById(R.id.btnToggleOverlay)

        btnGrantOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        btnGrantAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, getString(R.string.app_name) + " listesinden aç", Toast.LENGTH_LONG).show()
        }

        btnOpenSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btnToggleOverlay.setOnClickListener {
            if (PrefsManager.isOverlayRunning(this)) {
                stopOverlay()
            } else {
                startOverlay()
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 42
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionUi()
        refreshToggleButton()
    }

    private fun refreshPermissionUi() {
        val overlayGranted = Settings.canDrawOverlays(this)
        btnGrantOverlay.text = if (overlayGranted)
            getString(R.string.perm_overlay_granted) else getString(R.string.perm_overlay_grant)
        btnGrantOverlay.isEnabled = !overlayGranted

        val accessGranted = isAccessibilityServiceEnabled()
        btnGrantAccess.text = if (accessGranted)
            getString(R.string.perm_access_granted) else getString(R.string.perm_access_grant)
        btnGrantAccess.isEnabled = !accessGranted
    }

    private fun refreshToggleButton() {
        val running = PrefsManager.isOverlayRunning(this)
        btnToggleOverlay.text = if (running)
            getString(R.string.btn_stop_overlay) else getString(R.string.btn_start_overlay)
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val myComponent = ComponentName(this, GamepadAccessibilityService::class.java)
        return enabledServices.any {
            ComponentName(it.resolveInfo.serviceInfo.packageName, it.resolveInfo.serviceInfo.name) == myComponent
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_overlay_perm_needed, Toast.LENGTH_SHORT).show()
            return
        }
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, R.string.toast_access_perm_needed, Toast.LENGTH_SHORT).show()
        }
        val buttons = PrefsManager.loadButtons(this)
        if (buttons.isEmpty()) {
            Toast.makeText(this, R.string.toast_no_buttons, Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        refreshToggleButton()
    }

    private fun stopOverlay() {
        val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP)
        startService(intent)
        refreshToggleButton()
    }
}
