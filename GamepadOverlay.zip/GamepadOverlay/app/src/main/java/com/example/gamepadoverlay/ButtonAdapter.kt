package com.example.gamepadoverlay

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ButtonAdapter(
    private val items: MutableList<ButtonConfig>,
    private val onEdit: (ButtonConfig) -> Unit,
    private val onDelete: (ButtonConfig) -> Unit
) : RecyclerView.Adapter<ButtonAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvLabel: TextView = view.findViewById(R.id.tvLabel)
        val tvSub: TextView = view.findViewById(R.id.tvSub)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEdit)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_button_config, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvLabel.text = item.label
        holder.tvSub.text = "Boyut: ${item.sizeDp}dp · Şeffaflık: %${item.opacity} · ${if (item.shape == "circle") "Daire" else "Kare"}"
        holder.btnEdit.setOnClickListener { onEdit(item) }
        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<ButtonConfig>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
