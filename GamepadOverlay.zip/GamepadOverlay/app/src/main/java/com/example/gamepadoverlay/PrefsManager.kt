package com.example.gamepadoverlay

import android.content.Context
import org.json.JSONArray

/**
 * Basit SharedPreferences tabanlı ayar/tuş yöneticisi.
 * Harici kütüphaneye ihtiyaç duymadan (org.json ile) JSON okur/yazar.
 */
object PrefsManager {
    private const val PREFS_NAME = "gamepad_prefs"
    private const val KEY_BUTTONS = "buttons_json"
    private const val KEY_EDIT_MODE = "edit_mode"
    private const val KEY_OVERLAY_RUNNING = "overlay_running"
    private const val KEY_GLOBAL_OPACITY = "global_opacity"
    private const val KEY_GLOBAL_SIZE = "global_size"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadButtons(context: Context): MutableList<ButtonConfig> {
        val raw = prefs(context).getString(KEY_BUTTONS, null)
        if (raw.isNullOrEmpty()) {
            val defaults = ButtonConfig.defaultSet()
            saveButtons(context, defaults)
            return defaults
        }
        val arr = JSONArray(raw)
        val list = mutableListOf<ButtonConfig>()
        for (i in 0 until arr.length()) {
            list.add(ButtonConfig.fromJson(arr.getJSONObject(i)))
        }
        return list
    }

    fun saveButtons(context: Context, buttons: List<ButtonConfig>) {
        val arr = JSONArray()
        buttons.forEach { arr.put(it.toJson()) }
        prefs(context).edit().putString(KEY_BUTTONS, arr.toString()).apply()
    }

    fun isEditMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_EDIT_MODE, true)

    fun setEditMode(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_EDIT_MODE, value).apply()
    }

    fun isOverlayRunning(context: Context): Boolean =
        prefs(context).getBoolean(KEY_OVERLAY_RUNNING, false)

    fun setOverlayRunning(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_OVERLAY_RUNNING, value).apply()
    }

    fun getGlobalOpacity(context: Context): Int =
        prefs(context).getInt(KEY_GLOBAL_OPACITY, 80)

    fun setGlobalOpacity(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_GLOBAL_OPACITY, value).apply()
    }

    fun getGlobalSize(context: Context): Int =
        prefs(context).getInt(KEY_GLOBAL_SIZE, 64)

    fun setGlobalSize(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_GLOBAL_SIZE, value).apply()
    }
}
