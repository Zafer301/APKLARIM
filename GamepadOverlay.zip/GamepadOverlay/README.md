# Sanal Gamepad (Overlay) – Android Projesi

Bu proje, telefon ekranının üzerine yerleşen, **sürüklenebilir, boyutlandırılabilir,
şeffaflığı ayarlanabilir** sanal oyun tuşları (gamepad) gösteren bir Android
uygulamasıdır. Her tuş, basıldığında ekranda seçtiğiniz bir noktaya "sanal dokunuş"
gönderir; böylece dokunmatik kontrollü oyunlarınızı fiziksel tuş hissiyle oynayabilirsiniz.

## Özellikler

- 🎮 Ekranın her yerine tuş ekleyip kaldırabilirsiniz
- ✋ Düzenleme modunda tuşları parmağınızla sürükleyip istediğiniz yere koyabilirsiniz
- 🔍 Her tuşun köşesindeki tutamaçla boyutunu değiştirebilirsiniz (32–160dp)
- 👻 Her tuşun / tüm tuşların şeffaflığını ayarlayabilirsiniz
- 🎯 "Hedef nokta seç" ile her tuşun basıldığında ekranda nereye dokunacağını seçebilirsiniz
- 🔵/⬛ Daire veya kare şekil seçebilirsiniz
- 🔔 Bildirimden hızlıca "Düzenle / Oynat / Durdur" yapabilirsiniz
- 🔐 Gerekli tüm izinleri (üstte gösterme + erişilebilirlik + bildirim) uygulama içinden ister
- 🇹🇷 Tamamen Türkçe arayüz

## Nasıl Derlerim?

1. **Android Studio**'yu açın (Hedgehog / Iguana veya daha yeni bir sürüm önerilir).
2. `File > Open` ile bu klasörü (`GamepadOverlay`) seçin.
3. Android Studio ilk açılışta Gradle wrapper'ı kendisi tamamlayacaktır (internet
   bağlantısı ister). "Sync Now" çıkarsa tıklayın.
4. Üstteki yeşil ▶ (Run) tuşuna basarak telefonunuza/emülatöre kurun,
   **veya** `Build > Build Bundle(s) / APK(s) > Build APK(s)` ile `.apk` üretin.
5. Üretilen APK: `app/build/outputs/apk/debug/app-debug.apk`

> Not: `gradlew` dosyası projede var ama gradle-wrapper.jar ikili dosyası dahil
> edilmedi (metin ortamından ikili dosya üretilemiyor). Android Studio projeyi
> açtığınızda bunu otomatik indirip tamamlar. Eğer terminalden `./gradlew` ile
> derlemek isterseniz önce Android Studio'da bir kez `File > Sync Project with
> Gradle Files` yapmanız yeterli, wrapper jar'ı kendiliğinden oluşur.

## İlk Kurulumda Yapılacaklar (uygulama içinde)

1. Ana ekrandan **"Üstte Gösterme"** iznini verin (SYSTEM_ALERT_WINDOW) —
   tuşların diğer uygulamaların üzerinde görünmesini sağlar.
2. **"Erişilebilirlik"** iznini verin — açılan Ayarlar listesinde
   "Sanal Gamepad" servisini bulup açın. Bu, tuşa bastığınızda oyuna
   dokunuşu iletebilmek için gerekli.
3. **"Tuşları Düzenle"** ekranından istediğiniz tuşları ekleyin/silin,
   her birinin boyutunu, şeffaflığını ve "hedef noktasını" ayarlayın.
4. **"Gamepad'i Başlat"** ile overlay'i açın. Varsayılan olarak
   **düzenleme modunda** açılır (tuşları sürükleyip yerleştirebilirsiniz).
   Bildirimdeki **"Oynat"** butonuna basınca düzenleme kapanır ve tuşlar
   artık gerçek dokunuş göndermeye başlar.

## Proje Yapısı

```
app/src/main/java/com/example/gamepadoverlay/
 ├─ MainActivity.kt              -> İzinler ve başlat/durdur ekranı
 ├─ SettingsActivity.kt          -> Tuş ekle/sil/düzenle, genel ayarlar
 ├─ OverlayService.kt            -> Ekran üzerindeki tuşları çizen ön plan servisi
 ├─ GamepadAccessibilityService.kt -> Tuşa basınca sanal dokunuş gönderir
 ├─ ButtonConfig.kt              -> Tek bir tuşun veri modeli
 ├─ ButtonAdapter.kt             -> Ayarlar ekranındaki tuş listesi
 └─ PrefsManager.kt              -> Ayarları cihazda saklar (SharedPreferences)
```

## Bilinen Sınırlamalar / Geliştirme Fikirleri

- Şu an her tuş **tek dokunuş (tap)** gönderir; sürükleme/joystick tipi
  sürekli dokunuş henüz yok — `GamepadAccessibilityService.performTapAt`
  fonksiyonunu genişleterek analog joystick eklenebilir.
- Birden fazla "profil" (örn. farklı oyunlar için farklı tuş dizilimi)
  eklemek isterseniz `PrefsManager` içindeki tek `buttons_json` anahtarını
  profil adına göre çoğaltmanız yeterli.
- Google Play'de yayınlamak isterseniz erişilebilirlik servisinin amacını
  Play Console'da ayrıca açıklamanız gerekir (Erişilebilirlik API'sini
  "gerçek" erişilebilirlik amacı dışında kullanmak ek inceleme gerektirir).

İyi oyunlar! 🎮
